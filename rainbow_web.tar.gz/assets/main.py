import pygame
import asyncio
import math
import random
import os

# screen will be initialized inside async def main()
screen = None


# ============================================================
# SHARED VECTOR UTILITIES
# ============================================================
def vec_add(v1, v2): return (v1[0] + v2[0], v1[1] + v2[1])
def vec_sub(v1, v2): return (v1[0] - v2[0], v1[1] - v2[1])
def vec_mul(v, s): return (v[0] * s, v[1] * s)
def vec_dot(v1, v2): return v1[0] * v2[0] + v1[1] * v2[1]
def vec_len(v): return math.hypot(v[0], v[1])
def vec_norm(v):
    l = vec_len(v)
    return (v[0]/l, v[1]/l) if l > 0 else (0, 0)


# ============================================================
# SIMULATION 1: REFRACTION (Wave Visualization)
# ============================================================
async def run_refraction(screen):
    try:
        GRID_WIDTH, GRID_HEIGHT = 600, 350
        RENDER_SCALE = 4
        RENDER_W = GRID_WIDTH // RENDER_SCALE
        RENDER_H = GRID_HEIGHT // RENDER_SCALE
        COLOR_BG = (0, 0, 0)
        COLOR_UI_BG = (30, 30, 30)
        COLOR_GLASS = (30, 30, 90)

        class WaveRenderer:
            def __init__(self):
                self.width = RENDER_W
                self.height = RENDER_H
                self.refractive_index = 1.0
                self.time = 0.0
                self.base_wavelength = 30.0 / RENDER_SCALE
                self.frequency = 0.2
                self.beam_width = 50.0 / RENDER_SCALE
                self.boundary_slope = 0.0
                self.center_x = self.width // 2 - (20 // RENDER_SCALE)
                self.center_y = self.height // 2
                self.update_vectors()
                self.pivot = (self.center_x, self.center_y)

            def set_refractive_index(self, n):
                self.refractive_index = n

            def set_slope(self, slope):
                self.boundary_slope = slope
                self.update_vectors()

            def update_vectors(self):
                l_len = math.hypot(self.boundary_slope, 1.0)
                self.tangent = (self.boundary_slope / l_len, 1.0 / l_len)
                self.normal = (1.0 / l_len, -self.boundary_slope / l_len)

            def update(self):
                self.time += self.frequency

            def render(self, surface):
                w = self.width
                h = self.height
                n2 = self.refractive_index
                t = self.time
                k0 = (2 * math.pi) / self.base_wavelength
                k1_x, k1_y = k0, 0.0
                kt = k0 * self.tangent[0]
                k_glass_mag = n2 * k0
                kn_sq = k_glass_mag**2 - kt**2
                if kn_sq < 0: kn_sq = 0
                kn = math.sqrt(kn_sq)
                k2_x = kt * self.tangent[0] + kn * self.normal[0]
                k2_y = kt * self.tangent[1] + kn * self.normal[1]
                k2_len = math.hypot(k2_x, k2_y)
                if k2_len > 0:
                    dir2_x = k2_x / k2_len
                    dir2_y = k2_y / k2_len
                else:
                    dir2_x, dir2_y = 1.0, 0.0
                slope = self.boundary_slope
                cx = float(self.center_x)
                cy = float(self.center_y)
                pivot_x = float(self.pivot[0])
                pivot_y = float(self.pivot[1])
                beam_w = self.beam_width
                bg_r0, bg_g0, bg_b0 = COLOR_BG
                gl_r, gl_g, gl_b = COLOR_GLASS
                buf = bytearray(w * h * 3)
                for y in range(h):
                    y_rel = y - cy
                    boundary_x_at_y = slope * y_rel + cx
                    dy = y - pivot_y
                    row_offset = y * w * 3
                    for x in range(w):
                        dx = x - pivot_x
                        if x < boundary_x_at_y:
                            phase = k1_x * dx + k1_y * dy - t
                            dist_from_beam = abs(y - cy)
                            bg_r, bg_g, bg_b = bg_r0, bg_g0, bg_b0
                        else:
                            phase = k2_x * dx + k2_y * dy - t
                            dist_from_beam = abs(dx * dir2_y - dy * dir2_x)
                            bg_r, bg_g, bg_b = gl_r, gl_g, gl_b
                        val = math.sin(phase)
                        wave_intensity = val if val > 0.0 else 0.0
                        if dist_from_beam > beam_w:
                            fade = 1.0 - (dist_from_beam - beam_w) / 10.0
                            if fade < 0.0: fade = 0.0
                            wave_intensity *= fade
                        idx = row_offset + x * 3
                        if wave_intensity > 0.05:
                            w_int = int(wave_intensity * 255)
                            r = bg_r
                            g = bg_g + w_int
                            b = bg_b + w_int // 3
                            buf[idx]     = min(r, 255)
                            buf[idx + 1] = min(g, 255)
                            buf[idx + 2] = min(b, 255)
                        else:
                            buf[idx]     = bg_r
                            buf[idx + 1] = bg_g
                            buf[idx + 2] = bg_b
                small_surf = pygame.image.frombuffer(bytes(buf), (w, h), 'RGB')
                pygame.transform.scale(small_surf, (GRID_WIDTH, GRID_HEIGHT), surface)

        pygame.display.set_caption("Refraction: Wave Simulation")
        clock = pygame.time.Clock()
        font = pygame.font.Font(None, 22)
        renderer = WaveRenderer()
        sim_surface = pygame.Surface((GRID_WIDTH, GRID_HEIGHT))
        win_w, win_h = screen.get_size()
        back_btn_rect = pygame.Rect(10, 10, 100, 40)
        toggle_btn_rect = pygame.Rect(20, win_h - 75, 140, 40)
        slider_rect = pygame.Rect(200, win_h - 60, max(100, win_w - 400), 10)
        current_slope_mode = "Rak"
        dragging = False
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = event.pos
                    if back_btn_rect.collidepoint((mx, my)):
                        running = False
                    if toggle_btn_rect.collidepoint((mx, my)):
                        if current_slope_mode == "Sned":
                            renderer.set_slope(0.0)
                            current_slope_mode = "Rak"
                        else:
                            renderer.set_slope(0.4)
                            current_slope_mode = "Sned"
                    if slider_rect.collidepoint(mx, my) or abs(my - slider_rect.centery) < 20:
                        if slider_rect.left <= mx <= slider_rect.right:
                            dragging = True
                            mx = max(slider_rect.left, min(slider_rect.right, mx))
                            ratio = (mx - slider_rect.left) / slider_rect.width
                            renderer.set_refractive_index(1.0 + ratio * 2.0)
                elif event.type == pygame.MOUSEBUTTONUP:
                    dragging = False
                elif event.type == pygame.MOUSEMOTION:
                    if dragging:
                        mx = max(slider_rect.left, min(slider_rect.right, event.pos[0]))
                        ratio = (mx - slider_rect.left) / slider_rect.width
                        renderer.set_refractive_index(1.0 + ratio * 2.0)

            renderer.update()
            renderer.render(sim_surface)
            ui_height = 100
            render_h = max(1, win_h - ui_height)
            scaled_surf = pygame.transform.scale(sim_surface, (win_w, render_h))
            screen.fill(COLOR_BG)
            screen.blit(scaled_surf, (0, 0))

            pygame.draw.rect(screen, COLOR_UI_BG, (0, win_h - ui_height, win_w, ui_height))
            pygame.draw.rect(screen, (80, 80, 100), toggle_btn_rect, border_radius=5)
            toggle_txt = font.render("Boundary: " + current_slope_mode, True, (255, 255, 255))
            screen.blit(toggle_txt, (toggle_btn_rect.centerx - toggle_txt.get_width()//2, toggle_btn_rect.centery - toggle_txt.get_height()//2))

            pygame.draw.rect(screen, (100, 100, 100), slider_rect, border_radius=5)
            ratio = (renderer.refractive_index - 1.0) / 2.0
            knob_x = slider_rect.x + int(ratio * slider_rect.width)
            pygame.draw.circle(screen, (255, 255, 255), (knob_x, slider_rect.centery), 12)
            lbl_n = font.render("Brytningsindex (n): " + str(round(renderer.refractive_index, 2)), True, (255, 255, 255))
            screen.blit(lbl_n, (win_w//2 - lbl_n.get_width()//2, slider_rect.y - 30))
            screen.blit(font.render("1.0 (Luft)", True, (150,150,150)), (slider_rect.x, slider_rect.bottom + 5))
            screen.blit(font.render("3.0 (Segt)", True, (150,150,150)), (slider_rect.right - 70, slider_rect.bottom + 5))

            pygame.draw.rect(screen, (150, 50, 50), back_btn_rect, border_radius=5)
            back_txt = font.render("Meny", True, (255, 255, 255))
            screen.blit(back_txt, (back_btn_rect.centerx - back_txt.get_width()//2, back_btn_rect.centery - back_txt.get_height()//2))

            pygame.display.flip()
            clock.tick(30)
            await asyncio.sleep(0)
    except Exception as e:
        print("[RainbowSim] Error in refraction: " + str(e))
        import traceback; traceback.print_exc()


# ============================================================
# SIMULATION 2: PRISM (Photon Race)
# ============================================================
async def run_prism(screen):
    try:
        INTERNAL_W, INTERNAL_H = 1200, 600
        BACKGROUND_COLOR = (10, 10, 10)
        SPEED_AIR = 4.0
        STAGGER_SPACING = 35.0
        BUTTON_COLOR = (50, 80, 50)
        BUTTON_HOVER = (70, 100, 70)
        BUTTON_ACTIVE = (100, 150, 100)
        TEXT_WHITE = (255, 255, 255)

        RAINBOW_DATA = [
            {"name": "Red",    "rgb": (255, 0, 0),     "n": 1.25},
            {"name": "Orange", "rgb": (255, 127, 0),   "n": 1.29},
            {"name": "Yellow", "rgb": (255, 255, 0),   "n": 1.33},
            {"name": "Green",  "rgb": (0, 255, 0),     "n": 1.38},
            {"name": "Blue",   "rgb": (0, 0, 255),     "n": 1.42},
            {"name": "Indigo", "rgb": (75, 0, 130),    "n": 1.46},
            {"name": "Violet", "rgb": (148, 0, 211),   "n": 1.50},
        ]

        def intersect_segment_line(p1, p2, v1, v2):
            d = (v2[1] - v1[1]) * (p2[0] - p1[0]) - (v2[0] - v1[0]) * (p2[1] - p1[1])
            if d == 0: return None
            ua = ((v2[0] - v1[0]) * (p1[1] - v1[1]) - (v2[1] - v1[1]) * (p1[0] - v1[0])) / d
            ub = ((p2[0] - p1[0]) * (p1[1] - v1[1]) - (p2[1] - p1[1]) * (p1[0] - v1[0])) / d
            if 0 <= ua <= 1 and 0 <= ub <= 1: return ua
            return None

        def get_polygon_edges(verts):
            edges = []
            n = len(verts)
            for i in range(n):
                p1 = verts[i]
                p2 = verts[(i + 1) % n]
                edge_vec = vec_sub(p2, p1)
                normal = vec_norm((-edge_vec[1], edge_vec[0]))
                edges.append({'p1': p1, 'p2': p2, 'normal': normal})
            return edges

        def calculate_rotated_rect_verts(center, width, height, angle_deg):
            angle_rad = math.radians(angle_deg)
            cos_a, sin_a = math.cos(angle_rad), math.sin(angle_rad)
            hw, hh = width / 2, height / 2
            corners = [(-hw, -hh), (-hw, hh), (hw, hh), (hw, -hh)]
            verts = []
            for cx_c, cy_c in corners:
                verts.append((center[0] + cx_c * cos_a - cy_c * sin_a, center[1] + cx_c * sin_a + cy_c * cos_a))
            return verts

        def calculate_polygon_verts(center, radius, rotation_deg, num_sides):
            verts = []
            angle_step = 360.0 / num_sides
            start_angle = 90 if num_sides == 3 else 45
            for i in range(num_sides):
                angle = start_angle + i * angle_step - rotation_deg
                rad = math.radians(angle)
                verts.append((center[0] + radius * math.cos(rad), center[1] - radius * math.sin(rad)))
            return verts

        class PhysicsWorld:
            def __init__(self):
                self.mode = None
                self.verts = []
                self.edges = []
                self.medium_active = False

            def set_mode(self, mode):
                self.mode = mode
                if mode == "block_straight":
                    self.medium_active = True
                    self.verts = calculate_rotated_rect_verts((600, 300), 500, 250, 0)
                    self.edges = get_polygon_edges(self.verts)
                elif mode == "block_rotated":
                    self.medium_active = True
                    self.verts = calculate_rotated_rect_verts((600, 300), 350, 350, 30)
                    self.edges = get_polygon_edges(self.verts)
                elif mode == "triangle":
                    self.medium_active = True
                    self.verts = calculate_polygon_verts((600, 350), 250, 0, 3)
                    self.edges = get_polygon_edges(self.verts)
                elif mode == "air":
                    self.medium_active = False
                    self.verts = []
                    self.edges = []

            def trace_ray(self, start_pos, velocity, current_n, target_n):
                move_vec = velocity
                dist_to_move = vec_len(move_vec)
                if dist_to_move == 0: return start_pos, velocity, None
                end_pos = vec_add(start_pos, move_vec)
                if not self.medium_active: return end_pos, velocity, None
                best_t, hit_edge = 2.0, None
                for edge in self.edges:
                    t = intersect_segment_line(start_pos, end_pos, edge['p1'], edge['p2'])
                    if t is not None and t < best_t:
                        best_t = t
                        hit_edge = edge
                if hit_edge and best_t <= 1.0:
                    hit_pos = vec_add(start_pos, vec_mul(move_vec, best_t))
                    incident = vec_norm(velocity)
                    normal = hit_edge['normal']
                    dot_prod = vec_dot(incident, normal)
                    entering = dot_prod < 0
                    if entering:
                        n1, n2 = 1.0, target_n
                        effective_normal = normal
                    else:
                        n1, n2 = target_n, 1.0
                        effective_normal = vec_mul(normal, -1)
                    eta = n1 / n2
                    c1 = -vec_dot(incident, effective_normal)
                    cs2_sq = 1 - eta**2 * (1 - c1**2)
                    if cs2_sq < 0:
                        speed = vec_len(velocity)
                        refl_dir = vec_add(incident, vec_mul(effective_normal, 2 * c1))
                        new_velocity = vec_mul(refl_dir, speed)
                        new_inside_state = True
                    else:
                        term = eta * c1 - math.sqrt(cs2_sq)
                        refr_dir = vec_add(vec_mul(incident, eta), vec_mul(effective_normal, term))
                        new_speed = SPEED_AIR / n2
                        new_velocity = vec_mul(refr_dir, new_speed)
                        new_inside_state = entering
                    return hit_pos, new_velocity, {'t': best_t, 'new_inside': new_inside_state}
                else:
                    return end_pos, velocity, None

        class Photon:
            def __init__(self, data, y_pos, start_x_offset):
                self.color = data["rgb"]
                self.n = data["n"]
                self.pos = (50.0 - start_x_offset, y_pos)
                self.vel = (SPEED_AIR, 0.0)
                self.inside = False
                self.trail = []
                self.finished = False

            def update(self, world):
                if self.pos[0] > INTERNAL_W + 50:
                    self.finished = True
                    return
                remaining_t = 1.0
                current_pos = self.pos
                current_vel = self.vel
                for _ in range(3):
                    step_vel = vec_mul(current_vel, remaining_t)
                    new_pos, new_vel, hit = world.trace_ray(current_pos, step_vel, 1.0 if not self.inside else self.n, self.n)
                    if hit:
                        if new_pos[0] > -50: self.trail.append(new_pos)
                        self.inside = hit['new_inside']
                        current_vel = new_vel
                        consumed = hit['t']
                        remaining_t *= (1.0 - consumed)
                        epsilon = 0.1
                        current_pos = vec_add(new_pos, vec_mul(vec_norm(current_vel), epsilon))
                        if remaining_t <= 0.001: break
                    else:
                        current_pos = new_pos
                        if current_pos[0] > -50: self.trail.append(current_pos)
                        break
                self.pos = current_pos
                self.vel = current_vel

            def draw(self, surface):
                if self.pos[0] < -20: return
                if len(self.trail) > 1:
                    pygame.draw.lines(surface, self.color, False, self.trail, 6)
                pygame.draw.circle(surface, self.color, (int(self.pos[0]), int(self.pos[1])), 10)
                pygame.draw.circle(surface, (255, 255, 255), (int(self.pos[0]), int(self.pos[1])), 4)

        def reset_simulation():
            photons = []
            center_y = 300
            for i, data in enumerate(reversed(RAINBOW_DATA)):
                offset = i * STAGGER_SPACING
                photons.append(Photon(data, center_y, offset))
            return photons

        pygame.display.set_caption("Refraktion: Hastighetsloppet")
        clock = pygame.time.Clock()
        font = pygame.font.Font(None, 22)
        canvas = pygame.Surface((INTERNAL_W, INTERNAL_H))
        world = PhysicsWorld()
        photons = []

        y_pos = 50; w = 120; h = 40; gap_v = 10; x = 50
        btn_air = pygame.Rect(x, y_pos, w, h); x += w + gap_v
        btn_straight = pygame.Rect(x, y_pos, w, h); x += w + gap_v
        btn_rotated = pygame.Rect(x, y_pos, w, h); x += w + gap_v
        btn_tri = pygame.Rect(x, y_pos, w, h); x += w + gap_v
        x += 20
        btn_clear = pygame.Rect(x, y_pos, w, h)
        btn_back = pygame.Rect(INTERNAL_W - 130, 20, 110, 40)

        sim_surf = pygame.Surface((INTERNAL_W, INTERNAL_H))
        p_surf = pygame.Surface((INTERNAL_W, INTERNAL_H))

        running = True
        win_w, win_h = screen.get_size()

        while running:
            scale = min(win_w / INTERNAL_W, win_h / INTERNAL_H)
            new_w = int(INTERNAL_W * scale)
            new_h = int(INTERNAL_H * scale)
            offset_x = (win_w - new_w) // 2
            offset_y = (win_h - new_h) // 2

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        mx, my = event.pos
                        if offset_x <= mx < offset_x + new_w and offset_y <= my < offset_y + new_h:
                            logical_mx = (mx - offset_x) / scale
                            logical_my = (my - offset_y) / scale
                            scaled_pos = (logical_mx, logical_my)
                            if btn_back.collidepoint(scaled_pos):
                                running = False
                            elif btn_air.collidepoint(scaled_pos):
                                world.set_mode("air"); photons = reset_simulation()
                            elif btn_straight.collidepoint(scaled_pos):
                                world.set_mode("block_straight"); photons = reset_simulation()
                            elif btn_rotated.collidepoint(scaled_pos):
                                world.set_mode("block_rotated"); photons = reset_simulation()
                            elif btn_tri.collidepoint(scaled_pos):
                                world.set_mode("triangle"); photons = reset_simulation()
                            elif btn_clear.collidepoint(scaled_pos):
                                photons = []

            for p in photons: p.update(world)

            canvas.fill(BACKGROUND_COLOR)
            if world.medium_active:
                pygame.draw.polygon(canvas, (30, 40, 50), world.verts)
                pygame.draw.polygon(canvas, (100, 120, 150), world.verts, 2)
                name = ""
                if world.mode == "block_straight": name = "BLOCK (Rakt)"
                elif world.mode == "block_rotated": name = "BLOCK (Roterat)"
                elif world.mode == "triangle": name = "PRISMA"
                label = font.render(name, True, (100, 120, 150))
                canvas.blit(label, (600 - label.get_width()//2, 150))

            if photons:
                sim_surf.fill((0, 0, 0))
                for p in photons:
                    p_surf.fill((0, 0, 0))
                    p.draw(p_surf)
                    sim_surf.blit(p_surf, (0, 0), special_flags=pygame.BLEND_ADD)
                canvas.blit(sim_surf, (0, 0), special_flags=pygame.BLEND_ADD)

            buttons_list = [
                (btn_air, "Inget medium", world.mode == "air"),
                (btn_straight, "Rak", world.mode == "block_straight"),
                (btn_rotated, "Roterad", world.mode == "block_rotated"),
                (btn_tri, "Prisma", world.mode == "triangle"),
                (btn_clear, "Rensa", False),
                (btn_back, "Meny", False)
            ]
            raw_mx, raw_my = pygame.mouse.get_pos()
            scaled_mouse = (-1000, -1000)
            if offset_x <= raw_mx < offset_x + new_w and offset_y <= raw_my < offset_y + new_h:
                scaled_mouse = ((raw_mx - offset_x) / scale, (raw_my - offset_y) / scale)

            for rect, text, active in buttons_list:
                col = BUTTON_ACTIVE if active else BUTTON_COLOR
                if rect.collidepoint(scaled_mouse): col = BUTTON_HOVER
                if active: col = BUTTON_ACTIVE
                if rect == btn_back: col = (150, 50, 50)
                pygame.draw.rect(canvas, col, rect, border_radius=5)
                pygame.draw.rect(canvas, TEXT_WHITE, rect, 2, border_radius=5)
                t_surf = font.render(text, True, TEXT_WHITE)
                canvas.blit(t_surf, (rect.centerx - t_surf.get_width()//2, rect.centery - t_surf.get_height()//2))

            msg = ""
            if world.mode is None: msg = "Choose a mode to start the simulation."
            elif world.mode == "air": msg = "Vacuum: All colors travel at the same speed (c)."
            elif world.mode == "block_straight": msg = "Normal incidence: Light slows down but direction unchanged. Red is fastest."
            elif world.mode == "block_rotated": msg = "Refraction: Light bends and slows. Red is fastest."
            elif world.mode == "triangle": msg = "Dispersion: Shape amplifies speed difference and separates colors."
            msg_surf = font.render(msg, True, (150, 150, 150))
            canvas.blit(msg_surf, (INTERNAL_W//2 - msg_surf.get_width()//2, INTERNAL_H - 50))

            screen.fill(BACKGROUND_COLOR)
            scaled_surf = pygame.transform.scale(canvas, (new_w, new_h))
            screen.blit(scaled_surf, (offset_x, offset_y))

            pygame.display.flip()
            clock.tick(60)
            await asyncio.sleep(0)
    except Exception as e:
        print("[RainbowSim] Error in prism: " + str(e))
        import traceback; traceback.print_exc()


# ============================================================
# SIMULATION 3: RAY TRACING (Fresnel)
# ============================================================
async def run_raytrace(screen):
    try:
        INTERNAL_WIDTH, INTERNAL_HEIGHT = 1200, 800
        BACKGROUND_COLOR = (10, 15, 20)
        DROP_CENTER = (INTERNAL_WIDTH // 2, INTERNAL_HEIGHT // 2)
        DROP_RADIUS = 250
        N_AIR = 1.00
        N_WATER = 1.333
        MAX_DEPTH = 12
        MIN_INTENSITY = 0.001
        COLOR_BEAM = (255, 255, 230)
        DROP_FILL_COLOR = (20, 30, 50)
        DROP_OUTLINE_COLOR = (100, 150, 200)

        class RaySegment:
            def __init__(self, start, end, intensity, width=1):
                self.start = start
                self.end = end
                self.intensity = intensity
                self.width = width

        def intersect_ray_circle(ray_origin, ray_dir, circle_center, radius):
            oc = vec_sub(ray_origin, circle_center)
            a = vec_dot(ray_dir, ray_dir)
            b = 2.0 * vec_dot(oc, ray_dir)
            c = vec_dot(oc, oc) - radius*radius
            discriminant = b*b - 4*a*c
            if discriminant < 0: return None
            sqrt_disc = math.sqrt(discriminant)
            t1 = (-b - sqrt_disc) / (2*a)
            t2 = (-b + sqrt_disc) / (2*a)
            epsilon = 0.001
            if t1 > epsilon: return t1
            if t2 > epsilon: return t2
            return None

        def fresnel(n1, n2, cos_i, cos_t):
            if n1 == n2: return 0.0
            rs_num = n1 * cos_i - n2 * cos_t
            rs_den = n1 * cos_i + n2 * cos_t
            rs = (rs_num / rs_den) ** 2
            rp_num = n1 * cos_t - n2 * cos_i
            rp_den = n1 * cos_t + n2 * cos_i
            rp = (rp_num / rp_den) ** 2
            return 0.5 * (rs + rp)

        def trace_rays_recursive(start_pos, direction, intensity, current_n, segments, depth):
            if depth > MAX_DEPTH or intensity < MIN_INTENSITY:
                end_pos = vec_add(start_pos, vec_mul(direction, 100))
                segments.append(RaySegment(start_pos, end_pos, intensity * 0.5))
                return
            t = intersect_ray_circle(start_pos, direction, DROP_CENTER, DROP_RADIUS)
            if t is None:
                end_pos = vec_add(start_pos, vec_mul(direction, 2000))
                segments.append(RaySegment(start_pos, end_pos, intensity))
                return
            hit_point = vec_add(start_pos, vec_mul(direction, t))
            segments.append(RaySegment(start_pos, hit_point, intensity))
            normal = vec_norm(vec_sub(hit_point, DROP_CENTER))
            cos_incident = vec_dot(direction, normal)
            if abs(cos_incident) < 0.001: return
            entering = cos_incident < 0
            if entering:
                n1, n2 = N_AIR, N_WATER
                effective_normal = normal
                cos_i = -cos_incident
            else:
                n1, n2 = N_WATER, N_AIR
                effective_normal = vec_mul(normal, -1)
                cos_i = cos_incident
            sin_i2 = 1.0 - cos_i**2
            eta = n1 / n2
            sin_t2 = eta**2 * sin_i2
            nudge_dist = 0.1
            if sin_t2 > 1.0:
                refl_dir = vec_sub(direction, vec_mul(effective_normal, 2 * vec_dot(direction, effective_normal)))
                refl_start = vec_add(hit_point, vec_mul(effective_normal, nudge_dist))
                trace_rays_recursive(refl_start, refl_dir, intensity, current_n, segments, depth + 1)
            else:
                cos_t = math.sqrt(1.0 - sin_t2)
                R = fresnel(n1, n2, cos_i, cos_t)
                T = 1.0 - R
                refl_dir = vec_sub(direction, vec_mul(effective_normal, 2 * vec_dot(direction, effective_normal)))
                refl_start = vec_add(hit_point, vec_mul(effective_normal, nudge_dist))
                trace_rays_recursive(refl_start, refl_dir, intensity * R, current_n, segments, depth + 1)
                term = eta * cos_i - cos_t
                refr_dir = vec_add(vec_mul(direction, eta), vec_mul(effective_normal, term))
                refr_start = vec_add(hit_point, vec_mul(effective_normal, -nudge_dist))
                trace_rays_recursive(refr_start, refr_dir, intensity * T, n2, segments, depth + 1)

        pygame.display.set_caption("Realistic Ray Tracing (Fresnel)")
        clock = pygame.time.Clock()
        font = pygame.font.Font(None, 20)
        canvas = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))
        input_x_offset = -400.0
        dragging = False
        btn_back = pygame.Rect(INTERNAL_WIDTH - 120, 20, 100, 35)
        running = True
        win_w, win_h = screen.get_size()

        while running:
            scale = min(win_w / INTERNAL_WIDTH, win_h / INTERNAL_HEIGHT)
            new_w = int(INTERNAL_WIDTH * scale)
            new_h = int(INTERNAL_HEIGHT * scale)
            offset_x = (win_w - new_w) // 2
            offset_y = (win_h - new_h) // 2

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        mx, my = event.pos
                        if offset_x <= mx < offset_x + new_w and offset_y <= my < offset_y + new_h:
                            logical_mx = (mx - offset_x) / scale
                            logical_my = (my - offset_y) / scale
                            if btn_back.collidepoint((logical_mx, logical_my)):
                                running = False
                            else:
                                dragging = True
                elif event.type == pygame.MOUSEBUTTONUP:
                    dragging = False

            if dragging:
                mx, my = pygame.mouse.get_pos()
                if new_w > 0:
                    internal_mx = (mx - offset_x) / scale
                    rel_x = internal_mx - DROP_CENTER[0]
                    input_x_offset = rel_x

            segments = []
            start_pt = (DROP_CENTER[0] + input_x_offset, INTERNAL_HEIGHT)
            trace_rays_recursive(start_pt, (0, -1), 1.0, N_AIR, segments, 0)

            canvas.fill(BACKGROUND_COLOR)
            pygame.draw.circle(canvas, DROP_FILL_COLOR, DROP_CENTER, DROP_RADIUS)
            pygame.draw.circle(canvas, DROP_OUTLINE_COLOR, DROP_CENTER, DROP_RADIUS, 2)

            ray_layer = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))
            ray_layer.fill((0, 0, 0))
            for seg in segments:
                visual_intensity = math.sqrt(seg.intensity)
                visual_intensity = min(1.0, visual_intensity)
                draw_col = (
                    int(COLOR_BEAM[0] * visual_intensity),
                    int(COLOR_BEAM[1] * visual_intensity),
                    int(COLOR_BEAM[2] * visual_intensity)
                )
                if visual_intensity > 0.05:
                    pygame.draw.line(ray_layer, draw_col, seg.start, seg.end, 3)
            canvas.blit(ray_layer, (0, 0), special_flags=pygame.BLEND_ADD)

            title = font.render("Realistic Ray Tracing (R+T=1)", True, (200, 200, 200))
            canvas.blit(title, (20, 20))
            hint = font.render("Drag mouse to move light source.", True, (150, 150, 150))
            canvas.blit(hint, (20, 50))
            src_pos = (DROP_CENTER[0] + input_x_offset, INTERNAL_HEIGHT - 20)
            pygame.draw.circle(canvas, (255, 255, 200), (int(src_pos[0]), int(src_pos[1])), 8)

            mx, my = pygame.mouse.get_pos()
            log_mx = (mx - offset_x) / scale if scale > 0 else -1000
            log_my = (my - offset_y) / scale if scale > 0 else -1000
            back_col = (180, 50, 50) if btn_back.collidepoint((log_mx, log_my)) else (150, 50, 50)
            pygame.draw.rect(canvas, back_col, btn_back, border_radius=5)
            back_txt = font.render("Menu", True, (255, 255, 255))
            canvas.blit(back_txt, (btn_back.centerx - back_txt.get_width()//2, btn_back.centery - back_txt.get_height()//2))

            screen.fill(BACKGROUND_COLOR)
            scaled_surf = pygame.transform.scale(canvas, (new_w, new_h))
            screen.blit(scaled_surf, (offset_x, offset_y))
            pygame.display.flip()
            clock.tick(60)
            await asyncio.sleep(0)
    except Exception as e:
        print("[RainbowSim] Error in raytrace: " + str(e))
        import traceback; traceback.print_exc()


# ============================================================
# SIMULATION 4: DROPLET (Ray Path in Raindrop)
# ============================================================
async def run_droplet(screen):
    try:
        INTERNAL_WIDTH, INTERNAL_HEIGHT = 1200, 800
        BACKGROUND_COLOR = (20, 20, 20)
        UI_WIDTH = 250
        WHITE = (255, 255, 255)
        GRAY = (100, 100, 100)
        BUTTON_COLOR = (50, 50, 80)
        BUTTON_ACTIVE_COLOR = (80, 100, 80)
        DROP_FILL_COLOR = (20, 20, 60)
        DROP_OUTLINE_COLOR = (200, 200, 220)

        RAINBOW_DATA = [
            {"name": "Red",    "rgb": (255, 0, 0),     "n": 1.331},
            {"name": "Orange", "rgb": (255, 127, 0),   "n": 1.333},
            {"name": "Yellow", "rgb": (255, 255, 0),   "n": 1.335},
            {"name": "Green",  "rgb": (0, 255, 0),     "n": 1.338},
            {"name": "Blue",   "rgb": (0, 0, 255),     "n": 1.343},
            {"name": "Indigo", "rgb": (75, 0, 130),    "n": 1.345},
            {"name": "Violet", "rgb": (148, 0, 211),   "n": 1.348},
        ]

        class SimulationState:
            def __init__(self):
                self.visible_flags = [False] * 7
                self.focused_index = 0
                self.impact_primary = [100.0] * 7
                self.impact_secondary = [100.0] * 7
                self.is_dragging = False
                self.show_primary = True
                self.show_secondary = False

        def get_layout(current_w, current_h):
            ui_x = current_w - UI_WIDTH
            drop_center = (ui_x // 2, current_h // 2)
            max_radius_w = (ui_x - 50) // 6
            max_radius_h = current_h / 7.5
            drop_radius = int(min(max_radius_w, max_radius_h))
            return ui_x, drop_center, drop_radius

        def calculate_ray_path(x_offset, n_color, drop_center, drop_radius, screen_height, num_reflections):
            points = []
            start_x = drop_center[0] + x_offset
            start_y = screen_height
            points.append((start_x, start_y))
            if abs(x_offset) > drop_radius:
                points.append((start_x, 0))
                return points, None
            dy_entry = math.sqrt(drop_radius**2 - x_offset**2)
            entry_x = start_x
            entry_y = drop_center[1] + dy_entry
            points.append((entry_x, entry_y))
            try:
                alpha = math.asin(x_offset / drop_radius)
            except ValueError:
                return points, None
            sin_beta = (1.0003 / n_color) * math.sin(alpha)
            if abs(sin_beta) > 1: return points, None
            beta = math.asin(sin_beta)
            theta_current = math.atan2(dy_entry, x_offset)
            rotation_step = -(math.pi - 2 * beta)
            for _ in range(num_reflections):
                theta_current += rotation_step
                ref_x = drop_center[0] + drop_radius * math.cos(theta_current)
                ref_y = drop_center[1] + drop_radius * math.sin(theta_current)
                points.append((ref_x, ref_y))
            theta_current += rotation_step
            exit_x = drop_center[0] + drop_radius * math.cos(theta_current)
            exit_y = drop_center[1] + drop_radius * math.sin(theta_current)
            points.append((exit_x, exit_y))
            final_ray_angle = theta_current - alpha
            end_x = exit_x + 2000 * math.cos(final_ray_angle)
            end_y = exit_y + 2000 * math.sin(final_ray_angle)
            points.append((end_x, end_y))
            alpha_deg = math.degrees(abs(alpha))
            beta_deg = math.degrees(abs(beta))
            if num_reflections == 1: calc_deviation = 4 * beta_deg - 2 * alpha_deg
            else: calc_deviation = 180 + 2 * alpha_deg - 6 * beta_deg
            return points, abs(calc_deviation)

        def draw_ui_right_panel(surf, state, fnt, ui_x_start, screen_height):
            pygame.draw.rect(surf, (40, 40, 40), (ui_x_start, 0, UI_WIDTH, screen_height))
            pygame.draw.line(surf, GRAY, (ui_x_start, 0), (ui_x_start, screen_height), 2)
            title = fnt.render("Colors", True, WHITE)
            surf.blit(title, (ui_x_start + 20, 20))
            start_y = 60
            spacing = 50
            l1 = fnt.render("Vis", True, GRAY)
            l2 = fnt.render("Control", True, GRAY)
            surf.blit(l1, (ui_x_start + 10, start_y - 20))
            surf.blit(l2, (ui_x_start + 60, start_y - 20))
            for i, data in enumerate(RAINBOW_DATA):
                yp = start_y + i * spacing
                checkbox_rect = pygame.Rect(ui_x_start + 10, yp, 20, 20)
                pygame.draw.rect(surf, GRAY, checkbox_rect, 2)
                if state.visible_flags[i]:
                    pygame.draw.rect(surf, data["rgb"], (checkbox_rect.x+4, checkbox_rect.y+4, 12, 12))
                radio_center = (ui_x_start + 80, yp + 10)
                pygame.draw.circle(surf, GRAY, radio_center, 10, 2)
                if state.focused_index == i:
                    pygame.draw.circle(surf, WHITE, radio_center, 6)
                color_name = fnt.render(data["name"], True, data["rgb"])
                surf.blit(color_name, (ui_x_start + 110, yp))
            inst_y = screen_height - 120
            for idx, line in enumerate(["Drag Left side", "for Primary.", "Drag Right side", "for Secondary."]):
                inst_surf = fnt.render(line, True, GRAY)
                surf.blit(inst_surf, (ui_x_start + 10, inst_y + (idx*20)))

        def draw_top_controls(surf, state, fnt):
            buttons = []
            start_x = 20
            start_y = 20
            for label_text, flag, action in [
                ("Primary: " + ("ON" if state.show_primary else "OFF"), state.show_primary, "toggle_primary"),
                ("Secondary: " + ("ON" if state.show_secondary else "OFF"), state.show_secondary, "toggle_secondary"),
            ]:
                txt_surf = fnt.render(label_text, True, WHITE if flag else GRAY)
                rect = pygame.Rect(start_x, start_y, txt_surf.get_width() + 20, 35)
                color = BUTTON_ACTIVE_COLOR if flag else BUTTON_COLOR
                pygame.draw.rect(surf, color, rect, border_radius=5)
                pygame.draw.rect(surf, GRAY, rect, 2, border_radius=5)
                surf.blit(txt_surf, (rect.x + 10, rect.y + 8))
                buttons.append({"rect": rect, "action": action})
                start_x += rect.width + 20
            opt_surf = fnt.render("Optimize", True, WHITE)
            rect = pygame.Rect(start_x, start_y, opt_surf.get_width() + 20, 35)
            pygame.draw.rect(surf, BUTTON_COLOR, rect, border_radius=5)
            pygame.draw.rect(surf, GRAY, rect, 2, border_radius=5)
            surf.blit(opt_surf, (rect.x + 10, rect.y + 8))
            buttons.append({"rect": rect, "action": "set_optimal"})
            start_x += rect.width + 30
            back_txt = fnt.render("Menu", True, WHITE)
            rect = pygame.Rect(start_x, start_y, 80, 35)
            pygame.draw.rect(surf, (150, 50, 50), rect, border_radius=5)
            surf.blit(back_txt, (rect.centerx - back_txt.get_width()//2, rect.centery - back_txt.get_height()//2))
            buttons.append({"rect": rect, "action": "back"})
            return buttons

        def handle_click(pos, state, ui_x_start, top_buttons, drop_radius):
            x, y = pos
            for btn in top_buttons:
                if btn["rect"].collidepoint(pos):
                    if btn["action"] == "toggle_primary": state.show_primary = not state.show_primary
                    elif btn["action"] == "toggle_secondary": state.show_secondary = not state.show_secondary
                    elif btn["action"] == "set_optimal":
                        for i, data in enumerate(RAINBOW_DATA):
                            n = data["n"]
                            if 4 - n**2 > 0: state.impact_primary[i] = drop_radius * math.sqrt((4 - n**2) / 3)
                            if 9 - n**2 > 0: state.impact_secondary[i] = drop_radius * math.sqrt((9 - n**2) / 8)
                        state.show_primary = True; state.show_secondary = True
                    elif btn["action"] == "back": return "BACK"
                    return True
            if x >= ui_x_start:
                start_y = 60
                spacing = 50
                for i in range(len(RAINBOW_DATA)):
                    yp = start_y + i * spacing
                    if (ui_x_start + 10 <= x <= ui_x_start + 30) and (yp <= y <= yp + 20):
                        state.visible_flags[i] = not state.visible_flags[i]
                        state.focused_index = i
                    if (ui_x_start + 60 <= x <= ui_x_start + 100) and (yp <= y <= yp + 20):
                        state.focused_index = i
                return True
            return False

        pygame.display.set_caption("Ray Path in Raindrop")
        clock = pygame.time.Clock()
        font = pygame.font.Font(None, 20)
        big_font = pygame.font.Font(None, 24)
        state = SimulationState()
        canvas = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))
        buttons = []
        running = True
        win_w, win_h = screen.get_size()

        while running:
            ui_x_start, drop_center, drop_radius = get_layout(INTERNAL_WIDTH, INTERNAL_HEIGHT)
            scale = min(win_w / INTERNAL_WIDTH, win_h / INTERNAL_HEIGHT)
            new_w = int(INTERNAL_WIDTH * scale)
            new_h = int(INTERNAL_HEIGHT * scale)
            offset_x = (win_w - new_w) // 2
            offset_y = (win_h - new_h) // 2

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        mx, my = event.pos
                        if offset_x <= mx < offset_x + new_w and offset_y <= my < offset_y + new_h:
                            imx = (mx - offset_x) / scale
                            imy = (my - offset_y) / scale
                            ui_res = handle_click((imx, imy), state, ui_x_start, buttons, drop_radius)
                            if ui_res == "BACK":
                                running = False
                            elif not ui_res:
                                state.is_dragging = True
                elif event.type == pygame.MOUSEBUTTONUP:
                    state.is_dragging = False

            if state.is_dragging:
                mx_raw, my_raw = pygame.mouse.get_pos()
                imx = (mx_raw - offset_x) / scale
                if imx < ui_x_start:
                    dx = imx - drop_center[0]
                    raw_dist = abs(dx)
                    limit = drop_radius - 2
                    if raw_dist > limit: raw_dist = limit
                    if raw_dist < 5: raw_dist = 5
                    if dx < 0: state.impact_primary[state.focused_index] = raw_dist
                    else: state.impact_secondary[state.focused_index] = raw_dist

            canvas.fill(BACKGROUND_COLOR)
            pygame.draw.circle(canvas, DROP_FILL_COLOR, drop_center, drop_radius)
            pygame.draw.circle(canvas, DROP_OUTLINE_COLOR, drop_center, drop_radius, 2)
            pygame.draw.line(canvas, (50, 50, 50), (drop_center[0], 0), (drop_center[0], INTERNAL_HEIGHT), 1)
            pygame.draw.line(canvas, (50, 50, 50), (0, drop_center[1]), (ui_x_start, drop_center[1]), 1)

            focused_deviation_p = 0.0
            focused_deviation_s = 0.0
            ray_layer = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))
            ray_layer.fill((0, 0, 0))

            for i, data in enumerate(RAINBOW_DATA):
                if state.visible_flags[i]:
                    width = 4 if i == state.focused_index else 2
                    intensity = 1.0 if i == state.focused_index else 0.7
                    col = tuple(min(255, int(c * intensity)) for c in data["rgb"])
                    temp_surf = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))
                    temp_surf.fill((0,0,0))
                    if state.show_primary:
                        impact_p = state.impact_primary[i]
                        path_p, dev_p = calculate_ray_path(-impact_p, data["n"], drop_center, drop_radius, INTERNAL_HEIGHT, 1)
                        if path_p:
                            pygame.draw.lines(temp_surf, col, False, path_p, width)
                            if i == state.focused_index and dev_p is not None: focused_deviation_p = dev_p
                    if state.show_secondary:
                        impact_s = state.impact_secondary[i]
                        path_s, dev_s = calculate_ray_path(impact_s, data["n"], drop_center, drop_radius, INTERNAL_HEIGHT, 2)
                        if path_s:
                            pygame.draw.lines(temp_surf, col, False, path_s, width)
                            if i == state.focused_index and dev_s is not None: focused_deviation_s = dev_s
                    ray_layer.blit(temp_surf, (0,0), special_flags=pygame.BLEND_ADD)

            canvas.blit(ray_layer, (0,0), special_flags=pygame.BLEND_ADD)
            buttons = draw_top_controls(canvas, state, font)
            draw_ui_right_panel(canvas, state, font, ui_x_start, INTERNAL_HEIGHT)

            if focused_deviation_p or focused_deviation_s:
                txt_lines = ["Color: " + RAINBOW_DATA[state.focused_index]['name']]
                if state.show_primary and focused_deviation_p:
                    txt_lines.append("Primary angle: " + str(round(focused_deviation_p, 1)) + " deg")
                if state.show_secondary and focused_deviation_s:
                    txt_lines.append("Secondary angle: " + str(round(focused_deviation_s, 1)) + " deg")
                for idx, txt in enumerate(txt_lines):
                    surf = big_font.render(txt, True, WHITE)
                    canvas.blit(surf, (drop_center[0] + drop_radius + 20, drop_center[1] - drop_radius - 60 + idx*25))

            screen.fill(BACKGROUND_COLOR)
            scaled_surf = pygame.transform.scale(canvas, (new_w, new_h))
            screen.blit(scaled_surf, (offset_x, offset_y))
            pygame.display.flip()
            clock.tick(60)
            await asyncio.sleep(0)
    except Exception as e:
        print("[RainbowSim] Error in droplet: " + str(e))
        import traceback; traceback.print_exc()


# ============================================================
# SIMULATION 5: DROPLET2 (Animated Rainbow Builder)
# ============================================================
async def run_droplet2(screen):
    try:
        WIDTH, HEIGHT = 1200, 800
        BACKGROUND_COLOR = (5, 5, 5)
        DROP_CENTER = (WIDTH // 2, 200)
        DROP_RADIUS = 23
        WHITE = (255, 255, 255)
        GRAY = (100, 100, 100)
        BUTTON_COLOR = (50, 50, 80)
        BUTTON_CLEAR_COLOR = (100, 50, 50)
        DROP_FILL_COLOR = (20, 20, 60)
        DROP_OUTLINE_COLOR = (200, 200, 220)

        RAINBOW_DATA = [
            {"name": "Red",    "rgb": (255, 0, 0),     "n": 1.331},
            {"name": "Orange", "rgb": (255, 127, 0),   "n": 1.333},
            {"name": "Yellow", "rgb": (255, 255, 0),   "n": 1.335},
            {"name": "Green",  "rgb": (0, 255, 0),     "n": 1.338},
            {"name": "Blue",   "rgb": (0, 0, 255),     "n": 1.343},
            {"name": "Indigo", "rgb": (75, 0, 130),    "n": 1.345},
            {"name": "Violet", "rgb": (148, 0, 211),   "n": 1.348},
        ]

        def calc_ray_path(x_offset, n_color, num_reflections):
            points = []
            start_x = DROP_CENTER[0] + x_offset
            start_y = HEIGHT
            points.append((start_x, start_y))
            if abs(x_offset) > DROP_RADIUS * 0.999: return []
            dy_entry = math.sqrt(DROP_RADIUS**2 - x_offset**2)
            points.append((start_x, DROP_CENTER[1] + dy_entry))
            try:
                alpha = math.asin(x_offset / DROP_RADIUS)
            except ValueError: return []
            sin_beta = (1.0003 / n_color) * math.sin(alpha)
            if abs(sin_beta) > 1: return []
            beta = math.asin(sin_beta)
            theta_current = math.atan2(dy_entry, x_offset)
            rotation_step = -(math.pi - 2 * beta)
            for _ in range(num_reflections):
                theta_current += rotation_step
                points.append((DROP_CENTER[0] + DROP_RADIUS * math.cos(theta_current),
                               DROP_CENTER[1] + DROP_RADIUS * math.sin(theta_current)))
            theta_current += rotation_step
            exit_x = DROP_CENTER[0] + DROP_RADIUS * math.cos(theta_current)
            exit_y = DROP_CENTER[1] + DROP_RADIUS * math.sin(theta_current)
            points.append((exit_x, exit_y))
            final_ray_angle = theta_current - alpha
            points.append((exit_x + 3000 * math.cos(final_ray_angle),
                           exit_y + 3000 * math.sin(final_ray_angle)))
            return points

        def draw_buttons(surface, fnt, primary_visible, secondary_visible):
            buttons = []
            start_x = 20
            start_y = 20
            for text, visible, action in [
                ("Primary: " + ("CLEAR" if primary_visible else "START"), primary_visible, "toggle_primary"),
                ("Secondary: " + ("CLEAR" if secondary_visible else "START"), secondary_visible, "toggle_secondary"),
            ]:
                surf = fnt.render(text, True, WHITE)
                rect = pygame.Rect(start_x, start_y, surf.get_width() + 20, 35)
                color = BUTTON_CLEAR_COLOR if visible else BUTTON_COLOR
                pygame.draw.rect(surface, color, rect, border_radius=5)
                pygame.draw.rect(surface, GRAY, rect, 2, border_radius=5)
                surface.blit(surf, (rect.x + 10, rect.y + 8))
                buttons.append({"rect": rect, "action": action})
                start_x += rect.width + 20
            start_x += 10
            back_surf = fnt.render("Menu", True, WHITE)
            rect = pygame.Rect(start_x, start_y, 80, 35)
            pygame.draw.rect(surface, (150, 50, 50), rect, border_radius=5)
            surface.blit(back_surf, (rect.centerx - back_surf.get_width()//2, rect.centery - back_surf.get_height()//2))
            buttons.append({"rect": rect, "action": "back"})
            return buttons

        pygame.display.set_caption("Rainbow Builder")
        clock = pygame.time.Clock()
        font = pygame.font.Font(None, 20)
        canvas = pygame.Surface((WIDTH, HEIGHT))
        primary_layer = pygame.Surface((WIDTH, HEIGHT))
        secondary_layer = pygame.Surface((WIDTH, HEIGHT))
        primary_layer.fill((0,0,0))
        secondary_layer.fill((0,0,0))

        animating_primary = False
        primary_visible = False
        p_offset = -DROP_RADIUS * 0.98
        animating_secondary = False
        secondary_visible = False
        s_offset = -DROP_RADIUS * 0.98
        step_size = 0.2
        rays_per_frame = 1
        buttons = []
        running = True
        win_w, win_h = screen.get_size()

        while running:
            scale = min(win_w / WIDTH, win_h / HEIGHT)
            new_w = int(WIDTH * scale)
            new_h = int(HEIGHT * scale)
            offset_x = (win_w - new_w) // 2
            offset_y = (win_h - new_h) // 2

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        mx, my = event.pos
                        if offset_x <= mx < offset_x + new_w and offset_y <= my < offset_y + new_h:
                            lmx = (mx - offset_x) / scale
                            lmy = (my - offset_y) / scale
                            for btn in buttons:
                                if btn["rect"].collidepoint((lmx, lmy)):
                                    if btn["action"] == "toggle_primary":
                                        if primary_visible:
                                            animating_primary = False; primary_visible = False
                                            primary_layer.fill((0,0,0))
                                        else:
                                            animating_primary = True; primary_visible = True
                                            p_offset = -DROP_RADIUS * 0.98
                                            primary_layer.fill((0,0,0))
                                    elif btn["action"] == "toggle_secondary":
                                        if secondary_visible:
                                            animating_secondary = False; secondary_visible = False
                                            secondary_layer.fill((0,0,0))
                                        else:
                                            animating_secondary = True; secondary_visible = True
                                            s_offset = -DROP_RADIUS * 0.98
                                            secondary_layer.fill((0,0,0))
                                    elif btn["action"] == "back":
                                        running = False

            if animating_primary:
                for _ in range(rays_per_frame):
                    if p_offset > DROP_RADIUS * 0.98:
                        animating_primary = False
                        break
                    for data in reversed(RAINBOW_DATA):
                        col = data["rgb"]
                        path = calc_ray_path(p_offset, data["n"], 1)
                        if len(path) >= 2:
                            temp = pygame.Surface((WIDTH, HEIGHT))
                            temp.fill((0,0,0))
                            pygame.draw.lines(temp, col, False, path, 1)
                            primary_layer.blit(temp, (0,0), special_flags=pygame.BLEND_ADD)
                    p_offset += step_size

            if animating_secondary:
                for _ in range(rays_per_frame):
                    if s_offset > DROP_RADIUS * 0.98:
                        animating_secondary = False
                        break
                    for data in reversed(RAINBOW_DATA):
                        col = data["rgb"]
                        path = calc_ray_path(s_offset, data["n"], 2)
                        if len(path) >= 2:
                            temp = pygame.Surface((WIDTH, HEIGHT))
                            temp.fill((0,0,0))
                            pygame.draw.lines(temp, col, False, path, 1)
                            secondary_layer.blit(temp, (0,0), special_flags=pygame.BLEND_ADD)
                    s_offset += step_size

            canvas.fill(BACKGROUND_COLOR)
            pygame.draw.circle(canvas, DROP_FILL_COLOR, DROP_CENTER, DROP_RADIUS)
            pygame.draw.circle(canvas, DROP_OUTLINE_COLOR, DROP_CENTER, DROP_RADIUS, 2)
            canvas.blit(primary_layer, (0,0), special_flags=pygame.BLEND_ADD)
            if secondary_visible:
                dimmed = secondary_layer.copy()
                dimmer = pygame.Surface((WIDTH, HEIGHT))
                dimmer.fill((80, 80, 80))
                dimmed.blit(dimmer, (0,0), special_flags=pygame.BLEND_MULT)
                canvas.blit(dimmed, (0,0), special_flags=pygame.BLEND_ADD)

            buttons = draw_buttons(canvas, font, primary_visible, secondary_visible)

            screen.fill(BACKGROUND_COLOR)
            scaled_surf = pygame.transform.scale(canvas, (new_w, new_h))
            screen.blit(scaled_surf, (offset_x, offset_y))
            pygame.display.flip()
            clock.tick(60)
            await asyncio.sleep(0)
    except Exception as e:
        print("[RainbowSim] Error in droplet2: " + str(e))
        import traceback; traceback.print_exc()


# ============================================================
# SIMULATION 6: RAINBOW (Monte Carlo)
# ============================================================
async def run_rainbow(screen):
    try:
        INTERNAL_WIDTH, INTERNAL_HEIGHT = 1200, 800
        FOV_DEGREES = 70.0
        SUN_ELEVATION = 40.0
        GLOBAL_INTENSITY = 2.5
        MANUAL_CURSOR_OFFSET = (-10, -10)

        def gaussian(x, mu, sigma):
            return math.exp(-0.5 * ((x - mu) / sigma) ** 2)

        def get_rainbow_color(angle_deg):
            r, g, b = 0.0, 0.0, 0.0
            retro_peak = 0.8 * math.exp(-0.5 * (angle_deg / 0.8) ** 2)
            r += retro_peak; g += retro_peak; b += retro_peak
            if angle_deg < 42.0:
                glow = 0.20 + 0.08 * math.exp((angle_deg - 42.0) * 0.15)
                r += glow; g += glow; b += glow
            if 38.0 < angle_deg < 45.0:
                ip = 0.6
                b += ip * gaussian(angle_deg, 40.8, 1.4)
                g += ip * gaussian(angle_deg, 41.6, 1.3)
                r += ip * gaussian(angle_deg, 42.3, 1.3)
            if angle_deg > 50.0:
                r += 0.05; g += 0.05; b += 0.05
            if 48.0 < angle_deg < 56.0:
                si = 0.22
                r += si * gaussian(angle_deg, 50.6, 1.6)
                g += si * gaussian(angle_deg, 52.0, 1.6)
                b += si * gaussian(angle_deg, 53.4, 1.6)
            return r, g, b

        def create_fallback_landscape():
            surf = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))
            for y in range(INTERNAL_HEIGHT//2):
                val = int(255 * (y / (INTERNAL_HEIGHT//2)))
                col = (50, 100, 150 + val//3)
                pygame.draw.line(surf, col, (0, y), (INTERNAL_WIDTH, y))
            pygame.draw.rect(surf, (20, 40, 20), (0, INTERNAL_HEIGHT//2, INTERNAL_WIDTH, INTERNAL_HEIGHT//2))
            fb_font = pygame.font.Font(None, 32)
            txt = fb_font.render("No landscape.jpg found", True, (200, 200, 200))
            surf.blit(txt, (20, 20))
            return surf

        def calculate_pixel_color(px, py, asp_x, asp_y, view_dist, boost_intensity=False):
            dx = px - asp_x; dy = py - asp_y
            r_px = math.sqrt(dx*dx + dy*dy)
            angle = math.degrees(math.atan2(r_px, view_dist))
            if angle < 65.0:
                rf, gf, bf = get_rainbow_color(angle)
                if rf > 0.001 or gf > 0.001 or bf > 0.001:
                    brightness = 150
                    im = GLOBAL_INTENSITY
                    if boost_intensity: im *= 3.0
                    r = min(255, int(rf * brightness * im))
                    g = min(255, int(gf * brightness * im))
                    b = min(255, int(bf * brightness * im))
                    return (r, g, b)
            return (0, 0, 0)

        pygame.display.set_caption("Rainbow Simulation")
        clock = pygame.time.Clock()
        font = pygame.font.Font(None, 22)
        canvas = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))

        try:
            bg_image = pygame.image.load("landscape.jpg")
            bg_image = pygame.transform.scale(bg_image, (INTERNAL_WIDTH, INTERNAL_HEIGHT))
            print("[RainbowSim] landscape.jpg loaded")
        except Exception as img_err:
            print("[RainbowSim] landscape.jpg not found, using fallback: " + str(img_err))
            bg_image = create_fallback_landscape()

        fov_rad = math.radians(FOV_DEGREES)
        view_dist = (INTERNAL_WIDTH / 2) / math.tan(fov_rad / 2)
        asp_angle_rad = math.radians(SUN_ELEVATION)
        asp_pixel_y = (INTERNAL_HEIGHT / 2) + math.tan(asp_angle_rad) * view_dist
        asp_pixel_x = INTERNAL_WIDTH / 2
        rainbow_layer = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))
        rainbow_layer.fill((0, 0, 0))

        start_btn = pygame.Rect(10, 50, 120, 35)
        clear_btn = pygame.Rect(140, 50, 100, 35)
        back_btn = pygame.Rect(INTERNAL_WIDTH - 120, 50, 100, 35)

        running = True
        simulating = False
        manual_dragging = False
        manual_pos = (0, 0)
        points_per_frame = 2.0
        acceleration = 1.02
        max_points = 20000
        total_points = 0
        win_w, win_h = screen.get_size()

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        mx, my = event.pos
                        scale_x = INTERNAL_WIDTH / win_w
                        scale_y = INTERNAL_HEIGHT / win_h
                        logical_pos = (mx * scale_x, my * scale_y)
                        if back_btn.collidepoint(logical_pos):
                            running = False
                        elif start_btn.collidepoint(logical_pos):
                            simulating = not simulating
                        elif clear_btn.collidepoint(logical_pos):
                            rainbow_layer.fill((0,0,0))
                            total_points = 0
                            points_per_frame = 2.0
                        else:
                            manual_dragging = True
                            manual_pos = logical_pos
                elif event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 1 and manual_dragging:
                        target_pos = (manual_pos[0] + MANUAL_CURSOR_OFFSET[0], manual_pos[1] + MANUAL_CURSOR_OFFSET[1])
                        col = calculate_pixel_color(target_pos[0], target_pos[1], asp_pixel_x, asp_pixel_y, view_dist)
                        if col != (0,0,0):
                            temp_stamp = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))
                            temp_stamp.fill((0,0,0))
                            pygame.draw.circle(temp_stamp, col, (int(target_pos[0]), int(target_pos[1])), 6)
                            rainbow_layer.blit(temp_stamp, (0,0), special_flags=pygame.BLEND_MAX)
                            total_points += 1
                        manual_dragging = False
                elif event.type == pygame.MOUSEMOTION:
                    mx, my = event.pos
                    scale_x = INTERNAL_WIDTH / win_w
                    scale_y = INTERNAL_HEIGHT / win_h
                    manual_pos = (mx * scale_x, my * scale_y)

            if simulating:
                count = int(points_per_frame)
                frame_surface = pygame.Surface((INTERNAL_WIDTH, INTERNAL_HEIGHT))
                frame_surface.fill((0,0,0))
                if count > 0:
                    for _ in range(count):
                        px = int(random.uniform(0, INTERNAL_WIDTH - 1))
                        py = int(random.uniform(0, INTERNAL_HEIGHT - 1))
                        col = calculate_pixel_color(px, py, asp_pixel_x, asp_pixel_y, view_dist)
                        if col != (0,0,0):
                            frame_surface.set_at((px, py), col)
                    rainbow_layer.blit(frame_surface, (0,0), special_flags=pygame.BLEND_MAX)
                points_per_frame *= acceleration
                if points_per_frame > max_points: points_per_frame = max_points
                total_points += count

            canvas.blit(bg_image, (0, 0))
            canvas.blit(rainbow_layer, (0, 0), special_flags=pygame.BLEND_ADD)

            if manual_dragging:
                target_pos = (manual_pos[0] + MANUAL_CURSOR_OFFSET[0], manual_pos[1] + MANUAL_CURSOR_OFFSET[1])
                col = calculate_pixel_color(target_pos[0], target_pos[1], asp_pixel_x, asp_pixel_y, view_dist, boost_intensity=True)
                pygame.draw.circle(canvas, col, (int(target_pos[0]), int(target_pos[1])), 8)
                pygame.draw.circle(canvas, (255, 255, 255), (int(target_pos[0]), int(target_pos[1])), 9, 1)

            status = "Drops: " + str(total_points) + " | Speed: " + str(int(points_per_frame) if simulating else 0) + "/frame"
            txt = font.render(status, True, (255, 255, 255))
            canvas.blit(txt, (15, 15))

            raw_mx, raw_my = pygame.mouse.get_pos()
            scale_x = INTERNAL_WIDTH / win_w
            scale_y = INTERNAL_HEIGHT / win_h
            log_mx, log_my = raw_mx * scale_x, raw_my * scale_y

            btn_hover = start_btn.collidepoint((log_mx, log_my))
            if simulating:
                base_col = (100, 150, 100) if btn_hover else (60, 100, 60)
                text_str = "Stop Rain"
            else:
                base_col = (100, 100, 150) if btn_hover else (60, 60, 100)
                text_str = "Start Rain"
            pygame.draw.rect(canvas, base_col, start_btn, border_radius=5)
            pygame.draw.rect(canvas, (200, 200, 200), start_btn, 1, border_radius=5)
            btn_txt = font.render(text_str, True, (255, 255, 255))
            canvas.blit(btn_txt, (start_btn.centerx - btn_txt.get_width()//2, start_btn.centery - btn_txt.get_height()//2))

            clear_hover = clear_btn.collidepoint((log_mx, log_my))
            clear_col = (150, 100, 100) if clear_hover else (100, 60, 60)
            pygame.draw.rect(canvas, clear_col, clear_btn, border_radius=5)
            pygame.draw.rect(canvas, (200, 200, 200), clear_btn, 1, border_radius=5)
            clear_txt = font.render("Clear", True, (255, 255, 255))
            canvas.blit(clear_txt, (clear_btn.centerx - clear_txt.get_width()//2, clear_btn.centery - clear_txt.get_height()//2))

            back_hover = back_btn.collidepoint((log_mx, log_my))
            back_col = (180, 50, 50) if back_hover else (150, 50, 50)
            pygame.draw.rect(canvas, back_col, back_btn, border_radius=5)
            pygame.draw.rect(canvas, (200, 200, 200), back_btn, 1, border_radius=5)
            back_txt = font.render("Menu", True, (255, 255, 255))
            canvas.blit(back_txt, (back_btn.centerx - back_txt.get_width()//2, back_btn.centery - back_txt.get_height()//2))

            if not simulating and total_points == 0:
                inst = font.render("Click & Drag to place drops manually.", True, (200, 200, 200))
                canvas.blit(inst, (250, 60))

            scaled_surf = pygame.transform.scale(canvas, (win_w, win_h))
            screen.blit(scaled_surf, (0, 0))
            pygame.display.flip()
            clock.tick(60)
            await asyncio.sleep(0)
    except Exception as e:
        print("[RainbowSim] Error in rainbow: " + str(e))
        import traceback; traceback.print_exc()


# ============================================================
# MAIN MENU
# ============================================================
SIM_MAP = {
    "refraction": run_refraction,
    "prism": run_prism,
    "raytrace": run_raytrace,
    "droplet": run_droplet,
    "droplet2": run_droplet2,
    "rainbow": run_rainbow,
}


class MenuButton:
    def __init__(self, x, y, w, h, text, icon_name, module_name):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.icon_name = icon_name
        self.module_name = module_name
        self.hover = False

    def draw(self, surface, font, scale=1.0):
        s_rect = pygame.Rect(
            self.rect.x * scale,
            self.rect.y * scale,
            self.rect.width * scale,
            self.rect.height * scale
        )
        color = (60, 70, 80) if not self.hover else (80, 100, 120)
        border_col = (100, 100, 100) if not self.hover else (50, 150, 200)
        pygame.draw.rect(surface, (10, 10, 15), s_rect.move(4, 4), border_radius=int(10*scale))
        pygame.draw.rect(surface, color, s_rect, border_radius=int(10*scale))
        pygame.draw.rect(surface, border_col, s_rect, max(1, int(2*scale)), border_radius=int(10*scale))

        cx, cy = s_rect.centerx, s_rect.centery - int(15 * scale)
        isize = scale

        if self.icon_name == "refraction":
            y_level = cy + 5 * isize
            pygame.draw.line(surface, (150, 150, 150), (cx - 20*isize, y_level), (cx + 20*isize, y_level), max(1, int(2*isize)))
            pygame.draw.line(surface, (255, 255, 100), (cx - 15*isize, y_level - 20*isize), (cx, y_level), max(1, int(3*isize)))
            pygame.draw.line(surface, (255, 255, 100), (cx, y_level), (cx + 10*isize, y_level + 20*isize), max(1, int(3*isize)))
        elif self.icon_name == "prism":
            pts = [(cx, cy - 20*isize), (cx - 20*isize, cy + 15*isize), (cx + 20*isize, cy + 15*isize)]
            pygame.draw.polygon(surface, (200, 200, 200), pts, max(1, int(2*isize)))
            pygame.draw.line(surface, (255, 255, 255), (cx - 25*isize, cy), (cx - 10*isize, cy + 5*isize), max(1, int(2*isize)))
            pygame.draw.line(surface, (255, 255, 255), (cx - 10*isize, cy + 5*isize), (cx + 10*isize, cy + 5*isize), max(1, int(2*isize)))
            pygame.draw.line(surface, (255, 100, 100), (cx + 10*isize, cy + 5*isize), (cx + 25*isize, cy + 15*isize), max(1, int(2*isize)))
        elif self.icon_name == "fresnel":
            rad = int(15 * isize)
            pygame.draw.circle(surface, (100, 120, 150), (int(cx), int(cy)), rad, max(1, int(2*isize)))
            pygame.draw.line(surface, (255, 255, 200), (cx - 25*isize, cy), (cx - rad, cy), max(1, int(2*isize)))
            pygame.draw.line(surface, (200, 200, 180), (cx - rad, cy), (cx + rad, cy), max(1, int(1*isize)))
            pygame.draw.line(surface, (200, 200, 180), (cx - rad, cy), (cx - 20*isize, cy - 15*isize), max(1, int(2*isize)))
        elif self.icon_name == "ray_drop":
            rad = int(18 * isize)
            pygame.draw.circle(surface, (150, 200, 255), (int(cx), int(cy)), rad, max(1, int(2*isize)))
            p1 = (cx - rad, cy - 5*isize)
            p2 = (cx + rad*0.9, cy)
            p3 = (cx - rad*0.6, cy + rad*0.7)
            pygame.draw.lines(surface, (255, 255, 100), False, [p1, p2, p3], max(1, int(2*isize)))
        elif self.icon_name == "real_drop":
            color_drop = (50, 100, 200)
            rad = int(12 * isize)
            circle_center = (cx, cy + 5*isize)
            top_pt = (cx, cy - 20*isize)
            t1 = (cx - rad*0.8, circle_center[1] - rad*0.5)
            t2 = (cx + rad*0.8, circle_center[1] - rad*0.5)
            pygame.draw.polygon(surface, color_drop, [top_pt, t2, t1])
            pygame.draw.circle(surface, color_drop, (int(circle_center[0]), int(circle_center[1])), rad)
            pygame.draw.circle(surface, (200, 230, 255), (int(cx - 4*isize), int(cy - 2*isize)), max(1, int(3*isize)))
        elif self.icon_name == "rainbow":
            rect1 = (cx - 20*isize, cy - 10*isize, 40*isize, 40*isize)
            rect2 = (cx - 15*isize, cy - 5*isize, 30*isize, 30*isize)
            rect3 = (cx - 10*isize, cy, 20*isize, 20*isize)
            pygame.draw.arc(surface, (255, 100, 100), rect1, 0, 3.14, max(1, int(3*isize)))
            pygame.draw.arc(surface, (100, 255, 100), rect2, 0, 3.14, max(1, int(3*isize)))
            pygame.draw.arc(surface, (100, 100, 255), rect3, 0, 3.14, max(1, int(3*isize)))

        txt_surf = font.render(self.text, True, (240, 240, 240))
        surface.blit(txt_surf, (s_rect.centerx - txt_surf.get_width()//2, s_rect.centery + int(20*scale)))
        return s_rect


async def main():
    global screen

    print("[RainbowSim] main() starting...")
    await asyncio.sleep(0)  # Critical: let pygbag set up the canvas first

    print("[RainbowSim] Calling pygame.init()...")
    pygame.init()
    print("[RainbowSim] pygame.init() done")

    screen = pygame.display.set_mode((1280, 720))
    print("[RainbowSim] display created")

    await asyncio.sleep(0)  # yield again after display init

    # Draw loading screen immediately to verify canvas works
    screen.fill((20, 25, 30))
    loading_font = pygame.font.Font(None, 30)
    txt = loading_font.render("Loading RainbowSim...", True, (200, 200, 200))
    screen.blit(txt, (screen.get_width()//2 - txt.get_width()//2, screen.get_height()//2))
    pygame.display.flip()
    await asyncio.sleep(0)
    print("[RainbowSim] Initial screen drawn")

    BG_COLOR = (20, 25, 30)
    ACCENT_COLOR = (50, 150, 200)
    pygame.display.set_caption("Physics Simulator: Rainbow")
    clock = pygame.time.Clock()
    title_font = pygame.font.Font(None, 44)
    btn_font = pygame.font.Font(None, 24)
    base_w, base_h = 1000, 700
    cols = 3
    btn_w, btn_h = 200, 150
    gap = 40
    start_y = 200

    buttons = [
        MenuButton(0, 0, btn_w, btn_h, "Refraction", "refraction", "refraction"),
        MenuButton(0, 0, btn_w, btn_h, "Prism", "prism", "prism"),
        MenuButton(0, 0, btn_w, btn_h, "Raytrace", "fresnel", "raytrace"),
        MenuButton(0, 0, btn_w, btn_h, "Ray Path", "ray_drop", "droplet"),
        MenuButton(0, 0, btn_w, btn_h, "Rainbow Drop", "real_drop", "droplet2"),
        MenuButton(0, 0, btn_w, btn_h, "Rainbow", "rainbow", "rainbow"),
    ]

    grid_cols = min(cols, len(buttons))
    total_w = grid_cols * btn_w + (grid_cols - 1) * gap
    start_x = (base_w - total_w) // 2
    for i, btn in enumerate(buttons):
        row = i // cols
        col = i % cols
        btn.rect.x = start_x + col * (btn_w + gap)
        btn.rect.y = start_y + row * (btn_h + gap)

    print("[RainbowSim] Entering main menu loop")
    running = True
    while running:
        screen.fill(BG_COLOR)
        curr_w, curr_h = screen.get_size()
        scale = min(curr_w / base_w, curr_h / base_h)

        title = title_font.render("Physics Simulator: Rainbow", True, ACCENT_COLOR)
        screen.blit(title, (curr_w//2 - title.get_width()//2, int(80 * scale)))
        subtitle = btn_font.render("Choose a simulation to start", True, (150, 160, 170))
        screen.blit(subtitle, (curr_w//2 - subtitle.get_width()//2, int(130 * scale)))

        mx, my = pygame.mouse.get_pos()
        click_processed = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    click_processed = True

        for btn in buttons:
            s_rect = btn.draw(screen, btn_font, scale)
            is_hover = s_rect.collidepoint((mx, my))
            btn.hover = is_hover

            if click_processed and is_hover:
                sim_func = SIM_MAP.get(btn.module_name)
                if sim_func:
                    print("[RainbowSim] Launching " + btn.module_name)
                    pygame.event.clear()
                    try:
                        await sim_func(screen)
                    except Exception as e:
                        print("[RainbowSim] Error in " + btn.module_name + ": " + str(e))
                        import traceback; traceback.print_exc()
                    pygame.display.set_caption("Physics Simulator: Rainbow")
                    print("[RainbowSim] Returned to menu from " + btn.module_name)

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    print("[RainbowSim] Exiting")

asyncio.run(main())
