import pygame
import math
import asyncio

# --- Constants ---
GRID_WIDTH, GRID_HEIGHT = 600, 350

# Render at reduced resolution for performance (pure Python, no numpy)
RENDER_SCALE = 4
RENDER_W = GRID_WIDTH // RENDER_SCALE   # 150
RENDER_H = GRID_HEIGHT // RENDER_SCALE  # ~87

# Colors
COLOR_BG = (0, 0, 0)
COLOR_UI_BG = (30, 30, 30)
COLOR_GLASS = (30, 30, 90)
COLOR_OUTLINE = (200, 200, 220)


class WaveRenderer:
    def __init__(self):
        self.width = RENDER_W
        self.height = RENDER_H
        self.refractive_index = 1.0
        self.time = 0.0
        self.base_wavelength = 30.0 / RENDER_SCALE
        self.frequency = 0.2
        self.beam_width = 50.0 / RENDER_SCALE
        self.boundary_slope = 0.0
        self.center_x = self.width // 2 - (20 // RENDER_SCALE)
        self.center_y = self.height // 2

        self.update_vectors()
        self.pivot = (self.center_x, self.center_y)

    def set_refractive_index(self, n):
        self.refractive_index = n

    def set_slope(self, slope):
        self.boundary_slope = slope
        self.update_vectors()

    def update_vectors(self):
        l_len = math.hypot(self.boundary_slope, 1.0)
        self.tangent = (self.boundary_slope / l_len, 1.0 / l_len)
        self.normal = (1.0 / l_len, -self.boundary_slope / l_len)

    def update(self):
        self.time += self.frequency

    def render(self, surface):
        w = self.width
        h = self.height
        n2 = self.refractive_index
        t = self.time
        k0 = (2 * math.pi) / self.base_wavelength

        k1_x, k1_y = k0, 0.0
        kt = k0 * self.tangent[0]
        k_glass_mag = n2 * k0
        kn_sq = k_glass_mag**2 - kt**2
        if kn_sq < 0:
            kn_sq = 0
        kn = math.sqrt(kn_sq)

        k2_x = kt * self.tangent[0] + kn * self.normal[0]
        k2_y = kt * self.tangent[1] + kn * self.normal[1]

        k2_len = math.hypot(k2_x, k2_y)
        if k2_len > 0:
            dir2_x = k2_x / k2_len
            dir2_y = k2_y / k2_len
        else:
            dir2_x, dir2_y = 1.0, 0.0

        slope = self.boundary_slope
        cx = float(self.center_x)
        cy = float(self.center_y)
        pivot_x = float(self.pivot[0])
        pivot_y = float(self.pivot[1])
        beam_w = self.beam_width

        bg_r0, bg_g0, bg_b0 = COLOR_BG
        gl_r, gl_g, gl_b = COLOR_GLASS

        # Build pixel buffer using bytearray (no numpy needed)
        buf = bytearray(w * h * 3)

        for y in range(h):
            y_rel = y - cy
            boundary_x_at_y = slope * y_rel + cx
            dy = y - pivot_y
            row_offset = y * w * 3

            for x in range(w):
                dx = x - pivot_x
                if x < boundary_x_at_y:
                    phase = k1_x * dx + k1_y * dy - t
                    dist_from_beam = abs(y - cy)
                    bg_r, bg_g, bg_b = bg_r0, bg_g0, bg_b0
                else:
                    phase = k2_x * dx + k2_y * dy - t
                    dist_from_beam = abs(dx * dir2_y - dy * dir2_x)
                    bg_r, bg_g, bg_b = gl_r, gl_g, gl_b

                val = math.sin(phase)
                wave_intensity = val if val > 0.0 else 0.0

                if dist_from_beam > beam_w:
                    fade = 1.0 - (dist_from_beam - beam_w) / 10.0
                    if fade < 0.0:
                        fade = 0.0
                    wave_intensity *= fade

                idx = row_offset + x * 3
                if wave_intensity > 0.05:
                    w_int = int(wave_intensity * 255)
                    r = bg_r
                    g = bg_g + w_int
                    b = bg_b + w_int // 3
                    buf[idx]     = r if r < 255 else 255
                    buf[idx + 1] = g if g < 255 else 255
                    buf[idx + 2] = b if b < 255 else 255
                else:
                    buf[idx]     = bg_r
                    buf[idx + 1] = bg_g
                    buf[idx + 2] = bg_b

        # Create surface from buffer — no numpy required
        small_surf = pygame.image.frombuffer(bytes(buf), (w, h), 'RGB')
        # Scale up to full grid size
        pygame.transform.scale(small_surf, (GRID_WIDTH, GRID_HEIGHT), surface)


async def main(screen=None):
    if screen is None:
        pygame.init()
        screen = pygame.display.set_mode((1200, 700), pygame.RESIZABLE)

    pygame.display.set_caption("Vågbrytning: Simulering")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Arial", 18)

    renderer = WaveRenderer()
    sim_surface = pygame.Surface((GRID_WIDTH, GRID_HEIGHT))

    back_btn_rect = pygame.Rect(10, 10, 100, 40)
    toggle_btn_rect = pygame.Rect(20, 0, 120, 40)
    current_slope_mode = "Rak"

    def get_slider_rect(w, h):
        return pygame.Rect(200, h - 60, max(100, w - 400), 10)

    win_w, win_h = screen.get_width(), screen.get_height()
    slider_rect = get_slider_rect(win_w, win_h)
    toggle_btn_rect.y = win_h - 75

    dragging = False

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.VIDEORESIZE:
                win_w, win_h = event.w, event.h
                slider_rect = get_slider_rect(win_w, win_h)
                toggle_btn_rect.y = win_h - 75

            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = event.pos

                if back_btn_rect.collidepoint((mx, my)):
                    running = False

                if toggle_btn_rect.collidepoint((mx, my)):
                    if current_slope_mode == "Sned":
                        renderer.set_slope(0.0)
                        current_slope_mode = "Rak"
                    else:
                        renderer.set_slope(0.4)
                        current_slope_mode = "Sned"

                if slider_rect.collidepoint(mx, my) or abs(my - slider_rect.centery) < 20:
                    if slider_rect.left <= mx <= slider_rect.right:
                        dragging = True
                        mx = max(slider_rect.left, min(slider_rect.right, mx))
                        ratio = (mx - slider_rect.left) / slider_rect.width
                        new_n = 1.0 + ratio * 2.0
                        renderer.set_refractive_index(new_n)

            elif event.type == pygame.MOUSEBUTTONUP:
                dragging = False

            elif event.type == pygame.MOUSEMOTION:
                if dragging:
                    mx = event.pos[0]
                    mx = max(slider_rect.left, min(slider_rect.right, mx))
                    ratio = (mx - slider_rect.left) / slider_rect.width
                    new_n = 1.0 + ratio * 2.0
                    renderer.set_refractive_index(new_n)

        renderer.update()
        renderer.render(sim_surface)

        ui_height = 100
        render_h = max(1, win_h - ui_height)
        scaled_surf = pygame.transform.scale(sim_surface, (win_w, render_h))

        screen.fill(COLOR_BG)
        screen.blit(scaled_surf, (0, 0))

        # UI Panel
        pygame.draw.rect(screen, COLOR_UI_BG, (0, win_h - ui_height, win_w, ui_height))

        # Toggle Button
        pygame.draw.rect(screen, (80, 80, 100), toggle_btn_rect, border_radius=5)
        toggle_txt = font.render(f"Gräns: {current_slope_mode}", True, (255, 255, 255))
        screen.blit(toggle_txt, (toggle_btn_rect.centerx - toggle_txt.get_width()//2, toggle_btn_rect.centery - toggle_txt.get_height()//2))

        # Slider
        pygame.draw.rect(screen, (100, 100, 100), slider_rect, border_radius=5)
        ratio = (renderer.refractive_index - 1.0) / 2.0
        knob_x = slider_rect.x + int(ratio * slider_rect.width)
        pygame.draw.circle(screen, (255, 255, 255), (knob_x, slider_rect.centery), 12)

        lbl_n = font.render(f"Brytningsindex (n): {renderer.refractive_index:.2f}", True, (255, 255, 255))
        screen.blit(lbl_n, (win_w//2 - lbl_n.get_width()//2, slider_rect.y - 30))

        screen.blit(font.render("1.0 (Luft)", True, (150,150,150)), (slider_rect.x, slider_rect.bottom + 5))
        screen.blit(font.render("3.0 (Segt)", True, (150,150,150)), (slider_rect.right - 60, slider_rect.bottom + 5))

        # Back Button
        pygame.draw.rect(screen, (150, 50, 50), back_btn_rect, border_radius=5)
        back_txt = font.render("Meny", True, (255, 255, 255))
        screen.blit(back_txt, (back_btn_rect.centerx - back_txt.get_width()//2, back_btn_rect.centery - back_txt.get_height()//2))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    return

if __name__ == "__main__":
    asyncio.run(main())
